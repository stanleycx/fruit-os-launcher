package com.example.launcherios.ui.dock

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.toSize
import com.example.launcherios.data.AppInfo
import com.example.launcherios.data.AppRepository
import com.example.launcherios.ui.components.AppIcon
import com.example.launcherios.ui.home.DragState
import com.example.launcherios.ui.home.EditModeState
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.materials.HazeMaterials
import dev.chrisbanes.haze.HazeTint
import androidx.compose.foundation.border

/**
 * Le dock iOS : barre en bas avec jusqu'à 4 apps, fond semi-transparent.
 *
 * Supporte le drag and drop : on peut faire glisser des apps depuis et vers le dock.
 */
@Composable
fun Dock(
    apps: List<AppInfo>,
    appRepository: AppRepository,
    editMode: EditModeState,
    dragState: DragState,
    hazeState: dev.chrisbanes.haze.HazeState,  // 🆕
    onLongPress: () -> Unit,
    onRemoveApp: (AppInfo) -> Unit,
    onDragStart: (AppInfo, Offset) -> Unit,
    onDragDelta: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Calcul de l'ordre d'affichage : si on drag vers le dock, l'aperçu apparaît
    val dragged = dragState.draggedApp
    val displayApps = when {
        // App du dock en cours de drag : on la garde, isBeingDragged la masquera
        dragged != null && apps.any { it.packageName == dragged.packageName } -> {
            apps
        }
        // App d'ailleurs qui survole le dock MAIS dock plein : pas d'aperçu
        dragged != null && dragState.hoveringDock && apps.size >= 4 -> {
            apps  // Le dock reste tel quel = signal visuel "pas de place"
        }
        // App d'ailleurs qui survole le dock et dock non plein : aperçu
        dragged != null && dragState.hoveringDock -> {
            val safeSlot = dragState.hoverDockSlot.coerceIn(0, apps.size)
            buildList {
                addAll(apps.subList(0, safeSlot))
                add(dragged)
                addAll(apps.subList(safeSlot, apps.size))
            }
        }
        else -> apps
    }

    // Détection si le doigt survole le dock pendant un drag
    LaunchedEffect(dragState.position, dragState.isDragging) {
        if (!dragState.isDragging) return@LaunchedEffect

        val dockBounds = dragState.dockBounds ?: run {
            return@LaunchedEffect
        }
        val finger = dragState.position

        val isOverDock = finger.x in dockBounds.left..dockBounds.right &&
                finger.y in dockBounds.top..dockBounds.bottom

        if (isOverDock) {
            val relX = finger.x - dockBounds.left
            val slotWidth = dockBounds.width / 4f
            val slot = (relX / slotWidth).toInt().coerceIn(0, 3)

            dragState.hoveringDock = true
            dragState.hoverDockSlot = slot
            // Quand on est sur le dock, on invalide explicitement le hover de page
            dragState.hoverPageIndex = -1
            dragState.hoverSlotIndex = -1
        } else {
            // Quand on quitte le dock, on l'invalide seulement si c'était nous qui l'avions
            if (dragState.hoveringDock) {
                dragState.hoveringDock = false
                dragState.hoverDockSlot = -1
            }
        }
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .height(96.dp)  // 🆕 plus haut
            .clip(RoundedCornerShape(36.dp))  // un peu plus arrondi
            .hazeEffect(state = hazeState) {
                blurRadius = 30.dp
                tints = listOf(
                    dev.chrisbanes.haze.HazeTint(Color.White.copy(alpha = 0.25f))
                )
                noiseFactor = 0.05f
            }
            // 🆕 Bordure lumineuse blanche translucide (effet "lip" de verre)
            .border(
                width = 1.dp,
                brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.55f),   // Reflet brillant en haut
                        Color.White.copy(alpha = 0.15f),   // Diminue progressivement
                        Color.White.copy(alpha = 0.05f),   // Presque invisible en bas
                        Color.White.copy(alpha = 0.10f)    // Léger reflet sous (reflet du sol)
                    )
                ),
                shape = RoundedCornerShape(36.dp)
            )
            .padding(horizontal = 12.dp)
            // ...
            .onGloballyPositioned { coordinates ->
                dragState.dockBounds = Rect(
                    offset = coordinates.positionInRoot(),
                    size = coordinates.size.toSize()
                )
            },
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (app in displayApps.take(4)) {
            AppIcon(
                app = app,
                onClick = {
                    if (!editMode.isEditing) {
                        appRepository.launchApp(app.packageName)
                    }
                },
                onLongClick = onLongPress,
                onRemove = { onRemoveApp(app) },
                onDragStart = { position -> onDragStart(app, position) },
                onDrag = { delta -> onDragDelta(delta) },
                onDragEnd = onDragEnd,
                isEditing = editMode.isEditing,
                isBeingDragged = dragState.draggedApp?.packageName == app.packageName,
                showLabel = false, // 🆕 Pas de nom sous l'icône dans le dock (style iOS)
                iconSize = 72.dp  // 🆕 plus grand dans le dock
            )
        }
    }
}