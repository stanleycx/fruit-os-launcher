package com.example.launcherios.ui.components

import android.graphics.drawable.Drawable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

/**
 * Cache global des icônes rendues au format iOS.
 *
 * Une icône est rendue une seule fois (création du bitmap + calcul de la couleur de fond)
 * puis stockée ici. Tous les AppIcon partagent ce cache, donc même si Compose recompose
 * des AppIcon, on n'a pas à refaire le travail coûteux.
 */
object IconCache {
    private val cache = mutableMapOf<String, RenderedIconCached>()

    data class RenderedIconCached(
        val imageBitmap: ImageBitmap,
        val backgroundColor: androidx.compose.ui.graphics.Color
    )

    /**
     * Récupère l'icône rendue depuis le cache, ou la calcule si pas encore fait.
     */
    fun getOrRender(packageName: String, drawable: Drawable): RenderedIconCached {
        return cache.getOrPut(packageName) {
            val rendered = renderIosIcon(drawable, sizePx = 192)
            RenderedIconCached(
                imageBitmap = rendered.bitmap.asImageBitmap(),
                backgroundColor = rendered.backgroundColor
            )
        }
    }

    /**
     * Vide le cache (utile si l'app est mise à jour et que ses icônes changent).
     */
    fun clear() {
        cache.clear()
    }
}