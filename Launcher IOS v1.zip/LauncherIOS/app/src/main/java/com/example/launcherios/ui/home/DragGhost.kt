package com.example.launcherios.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.launcherios.ui.components.IosIconShape
import com.example.launcherios.ui.components.renderIosIcon
import kotlin.math.roundToInt

/**
 * Affiche l'icône "fantôme" qui suit le doigt pendant un drag.
 *
 * Utilise Modifier.offset { IntOffset } pour positionner précisément en pixels.
 */
@Composable
fun DragGhost(dragState: DragState) {
    val app = dragState.draggedApp ?: return

    val cached = remember(app.packageName) {
        com.example.launcherios.ui.components.IconCache.getOrRender(app.packageName, app.icon)
    }
    val imageBitmap = cached.imageBitmap
    val backgroundColor = cached.backgroundColor

    // Icône fantôme positionnée absolument
    // Le 30dp (en pixels) est la moitié de la taille de l'icône, pour la centrer sous le doigt
    Box(
        modifier = Modifier
            .offset {
                IntOffset(
                    x = (dragState.position.x - 90).roundToInt(),  // 90px ≈ 30dp à densité 3x
                    y = (dragState.position.y - 90).roundToInt()
                )
            }
            .size(60.dp)
            .scale(1.15f)
            .shadow(elevation = 12.dp, shape = IosIconShape, clip = false)
            .clip(IosIconShape)
            .background(backgroundColor)
    ) {
        Image(
            bitmap = imageBitmap,
            contentDescription = app.label,
            modifier = Modifier.fillMaxSize()
        )
    }
}