package com.example.launcherios.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.toSize
import com.example.launcherios.data.AppInfo
import com.example.launcherios.data.AppRepository
import com.example.launcherios.ui.components.AppIcon

private const val GRID_COLUMNS = 4

@Composable
fun HomePage(
    apps: List<AppInfo>,
    appRepository: AppRepository,
    editMode: EditModeState,
    dragState: DragState,
    pageIndex: Int,
    onLongPress: () -> Unit,
    onRemoveApp: (AppInfo) -> Unit,
    onDragStart: (AppInfo, Offset) -> Unit,
    onDragDelta: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Calcul de l'ordre d'affichage : seulement si le drag concerne cette page
    val displayApps by remember(apps, dragState.draggedApp, dragState.hoverSlotIndex, dragState.hoverPageIndex) {
        derivedStateOf {
            val dragged = dragState.draggedApp
            if (dragged == null || dragState.hoverPageIndex != pageIndex || dragState.hoverSlotIndex < 0) {
                apps
            } else {
                computeReorderedApps(
                    apps = apps,
                    draggedPackage = dragged.packageName,
                    targetIndex = dragState.hoverSlotIndex
                )
            }
        }
    }

    // Calcul de la cellule survolée par maths (méthode stable)
    LaunchedEffect(dragState.position, dragState.isDragging, apps.size) {
        if (!dragState.isDragging) return@LaunchedEffect

        val gridBounds = dragState.pageGridBounds[pageIndex] ?: return@LaunchedEffect
        val finger = dragState.position

        // Si le doigt est hors de la grille (par ex. sur le dock), on invalide le hover de cette page
        if (finger.x !in gridBounds.left..gridBounds.right ||
            finger.y !in gridBounds.top..gridBounds.bottom) {
            if (dragState.hoverPageIndex == pageIndex) {
                dragState.hoverPageIndex = -1
                dragState.hoverSlotIndex = -1
            }
            return@LaunchedEffect
        }

        // Si on revient sur la grille après avoir été sur le dock, on désactive le dock
        if (dragState.hoveringDock) {
            dragState.hoveringDock = false
            dragState.hoverDockSlot = -1
        }

        val relX = finger.x - gridBounds.left
        val relY = finger.y - gridBounds.top
        // Calcul exact de la hauteur de cellule en fonction du nombre de lignes affichées
// Pour une grille de 4 colonnes, le nombre de lignes est ceil(apps.size / 4)
        val cellWidth = gridBounds.width / GRID_COLUMNS
        val numRows = ((apps.size + GRID_COLUMNS - 1) / GRID_COLUMNS).coerceAtLeast(1)
// La grille a un padding top de 60dp + bottom de 20dp + spacing de 24dp entre les lignes
// On calcule la hauteur dispo et la hauteur d'une cellule incluant son spacing
        val gridContentHeight = gridBounds.height
        val cellHeight = if (numRows > 0) gridContentHeight / numRows else cellWidth * 1.4f

        val col = (relX / cellWidth).toInt().coerceIn(0, GRID_COLUMNS - 1)
        val row = (relY / cellHeight).toInt().coerceAtLeast(0)

        // On autorise l'insertion jusqu'à apps.size (= placement en fin de page)
// Pour les apps déjà sur la page, c'est limité à apps.size - 1
// Pour les apps venant d'ailleurs, on peut placer en position apps.size (à la fin)
        val maxSlot = if (dragState.draggedApp != null &&
            apps.any { it.packageName == dragState.draggedApp?.packageName }) {
            apps.size - 1  // app déjà dans cette page
        } else {
            apps.size  // app vient d'ailleurs, peut être insérée à la fin
        }
        val slotIndex = (row * GRID_COLUMNS + col).coerceAtMost(maxSlot)
        if (slotIndex >= 0) {
            dragState.hoverPageIndex = pageIndex
            dragState.hoverSlotIndex = slotIndex
        }
    }

    LazyVerticalGrid(
        columns = GridCells.Fixed(GRID_COLUMNS),
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            // Capture les bounds de la grille pour la détection
            .onGloballyPositioned { coordinates ->
                dragState.pageGridBounds[pageIndex] = Rect(
                    offset = coordinates.positionInRoot(),
                    size = coordinates.size.toSize()
                )
            },
        verticalArrangement = Arrangement.spacedBy(20.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        contentPadding = PaddingValues(top = 60.dp, bottom = 20.dp)
    ) {
        items(displayApps, key = { it.packageName }) { app ->
            AppIcon(
                app = app,
                onClick = {
                    if (!editMode.isEditing) {
                        appRepository.launchApp(app.packageName)
                    }
                },
                onLongClick = onLongPress,
                onRemove = { onRemoveApp(app) },
                onDragStart = { position -> onDragStart(app, position) },
                onDrag = { delta -> onDragDelta(delta) },
                onDragEnd = onDragEnd,
                isEditing = editMode.isEditing,
                isBeingDragged = dragState.draggedApp?.packageName == app.packageName,
                modifier = if (dragState.isDragging) Modifier.animateItem() else Modifier
            )
        }
    }
}

private fun computeReorderedApps(
    apps: List<AppInfo>,
    draggedPackage: String,
    targetIndex: Int
): List<AppInfo> {
    val draggedApp = apps.find { it.packageName == draggedPackage } ?: return apps
    val without = apps.filter { it.packageName != draggedPackage }
    val safeTarget = targetIndex.coerceIn(0, without.size)
    return buildList {
        addAll(without.subList(0, safeTarget))
        add(draggedApp)
        addAll(without.subList(safeTarget, without.size))
    }
}