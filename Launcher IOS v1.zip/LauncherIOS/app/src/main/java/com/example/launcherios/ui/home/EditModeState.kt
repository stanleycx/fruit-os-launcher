package com.example.launcherios.ui.home

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

/**
 * État global du mode édition (équivalent du "jiggle mode" d'iOS).
 *
 * Cet objet est créé une seule fois dans le HomeScreen et passé aux composants enfants
 * (HomePage, AppIcon...) pour qu'ils sachent s'ils doivent trembloter, afficher le
 * bouton de suppression, etc.
 */
class EditModeState {
    var isEditing: Boolean by mutableStateOf(false)
        private set

    /**
     * Active le mode édition (typiquement appelé sur un long-press).
     */
    fun enter() {
        isEditing = true
    }

    /**
     * Désactive le mode édition (tap ailleurs, bouton home, etc.).
     */
    fun exit() {
        isEditing = false
    }
}

/**
 * Crée et mémorise un EditModeState pour qu'il survive aux recompositions.
 */
@Composable
fun rememberEditModeState(): EditModeState {
    return remember { EditModeState() }
}

/**
 * Fournit la valeur de rotation animée pour le "tremblement" iOS.
 *
 * Quand isEditing = true, retourne un angle qui oscille en boucle entre
 * -2° et +2°. Sinon, retourne 0°.
 *
 * Pour donner un effet "naturel" (chaque icône tremble dans son propre rythme),
 * on prend en paramètre un seed (par ex. le hashCode du packageName) qui décale
 * légèrement la phase de l'animation.
 */
@Composable
fun useJiggleAngle(isEditing: Boolean, seed: Int = 0): Float {
    if (!isEditing) return 0f

    val transition = rememberInfiniteTransition(label = "jiggle")

    // Direction de départ aléatoire selon le seed (donne un effet désynchronisé)
    val direction = if (seed % 2 == 0) 1f else -1f
    val baseDuration = 180  // durée d'un demi-cycle en ms
    val duration = baseDuration + (seed % 40)  // léger jitter entre 180 et 220ms

    val angle by transition.animateFloat(
        initialValue = -2f * direction,
        targetValue = 2f * direction,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = duration),
            repeatMode = RepeatMode.Reverse
        ),
        label = "jiggle_angle"
    )

    return angle
}