package com.example.launcherios.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.launcherios.data.AppInfo
import com.example.launcherios.ui.home.useJiggleAngle
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.geometry.Offset
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import com.example.launcherios.ui.components.Haptics

/**
 * Affiche une icône d'app style iOS, avec gestion du mode édition.
 *
 * @param app L'app à afficher
 * @param onClick Action au tap normal
 * @param onLongClick Action au long-press (généralement : entrer en mode édition)
 * @param onRemove Action au clic sur le bouton "−" (en mode édition uniquement)
 * @param isEditing Si true, l'icône tremble et le bouton "−" est visible
 */
@Composable
fun AppIcon(
    app: AppInfo,
    onClick: () -> Unit,
    onLongClick: () -> Unit = {},
    onRemove: () -> Unit = {},
    onDragStart: (Offset) -> Unit = {},
    onDrag: (Offset) -> Unit = {},
    onDragEnd: () -> Unit = {},
    isEditing: Boolean = false,
    isBeingDragged: Boolean = false,
    showLabel: Boolean = true,
    iconSize: androidx.compose.ui.unit.Dp = 68.dp,  // 🆕
    modifier: Modifier = Modifier
) {
    val cached = remember(app.packageName) {
        IconCache.getOrRender(app.packageName, app.icon)
    }
    val imageBitmap = cached.imageBitmap
    val backgroundColor = cached.backgroundColor

    val jiggleAngle = useJiggleAngle(
        isEditing = isEditing,
        seed = app.packageName.hashCode()
    )

    val context = LocalContext.current

// Animation de "pop" quand le drag démarre : 1.0 → 1.15
    val popScale by animateFloatAsState(
        targetValue = if (isBeingDragged) 1.15f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessHigh
        ),
        label = "pop_scale"
    )

    // On stocke la position dans une référence "non observée" pour éviter les recompositions
    val positionRef = remember { mutableStateOf(Offset.Zero) }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            // Capture la position absolue de cette icône (utile pour le drag)
            .onGloballyPositioned { coordinates ->
                // On stocke directement dans le ref sans déclencher de recomposition
                positionRef.value = coordinates.positionInRoot()
            }
            // Détecteur de taps (toujours actif)
            .pointerInput(app.packageName) {
                detectTapGestures(
                    onTap = { onClick() },
                    onLongPress = { onLongClick() }
                )
            }
            // Détecteur de drag (uniquement en mode édition)
            .pointerInput(app.packageName, isEditing) {
                if (isEditing) {
                    detectDragGestures(
                        onDragStart = { offsetInIcon ->
                            Haptics.light(context)
                            onDragStart(positionRef.value + offsetInIcon)
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            onDrag(dragAmount)
                        },
                        onDragEnd = { onDragEnd() },
                        onDragCancel = { onDragEnd() }
                    )
                }
            }
            // Si on est en train d'être draggé, on devient invisible localement
            // (le fantôme prend le relais visuellement)
            .alpha(if (isBeingDragged) 0f else 1f)
    ) {
        Box(
            modifier = Modifier
                .size(iconSize + 10.dp)  // un peu plus grand pour laisser de la place au "−"
                .scale(popScale)
                .rotate(jiggleAngle),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(iconSize)
                    .shadow(elevation = 4.dp, shape = IosIconShape, clip = false)
                    .clip(IosIconShape)
                    .background(backgroundColor),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    bitmap = imageBitmap,
                    contentDescription = app.label,
                    modifier = Modifier.fillMaxSize()
                )
            }

            if (isEditing) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .size(22.dp)
                        .offset(x = 2.dp, y = 2.dp)
                        .shadow(elevation = 2.dp, shape = CircleShape)
                        .clip(CircleShape)
                        .background(Color.White)
                        .pointerInput(app.packageName) {
                            detectTapGestures(onTap = { onRemove() })
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(width = 10.dp, height = 2.dp)
                            .background(Color.Black)
                    )
                }
            }
        }

        if (showLabel) {
            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = app.label,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                maxLines = 1,
                style = androidx.compose.ui.text.TextStyle(
                    shadow = androidx.compose.ui.graphics.Shadow(
                        color = Color.Black.copy(alpha = 0.5f),
                        offset = androidx.compose.ui.geometry.Offset(0f, 1f),
                        blurRadius = 4f
                    )
                )
            )
        }
    }
}