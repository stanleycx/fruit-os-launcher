package com.example.launcherios.ui.home

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import com.example.launcherios.data.AppInfo

/**
 * État global du drag and drop.
 */
class DragState {
    var draggedApp: AppInfo? by mutableStateOf(null)
        private set

    var position: Offset by mutableStateOf(Offset.Zero)
        private set

    /** Page (index) sous le doigt. -1 si on ne survole aucune page. */
    var hoverPageIndex: Int by mutableStateOf(-1)

    /** Slot dans la page sous le doigt (0..23). -1 si invalide. */
    var hoverSlotIndex: Int by mutableStateOf(-1)

    /** True si le doigt survole le dock pendant un drag. */
    var hoveringDock: Boolean by mutableStateOf(false)

    /** Slot dans le dock sous le doigt (0..3). */
    var hoverDockSlot: Int by mutableStateOf(-1)

    /** Bounds du dock à l'écran (mis à jour par Dock via onGloballyPositioned). */
    var dockBounds: Rect? by mutableStateOf(null)

    val isDragging: Boolean
        get() = draggedApp != null

    /**
     * Bounds de la grille de chaque page (par pageIndex).
     * Mis à jour par chaque HomePage via onGloballyPositioned.
     */
    val pageGridBounds = mutableStateMapOf<Int, Rect>()

    fun start(app: AppInfo, startPosition: Offset) {
        draggedApp = app
        position = startPosition
    }

    fun update(newPosition: Offset) {
        position = newPosition
    }

    /**
     * Détermine si la position actuelle du doigt est sur le dock.
     * Utile au moment du drop pour décider en temps réel.
     */
    fun isOverDock(): Boolean {
        val bounds = dockBounds ?: return false
        return position.x in bounds.left..bounds.right &&
                position.y in bounds.top..bounds.bottom
    }

    /**
     * Calcule le slot dans le dock (0..3) à la position actuelle du doigt.
     */
    fun computeDockSlot(): Int {
        val bounds = dockBounds ?: return -1
        val relX = position.x - bounds.left
        val slotWidth = bounds.width / 4f
        return (relX / slotWidth).toInt().coerceIn(0, 3)
    }

    fun end() {
        draggedApp = null
        position = Offset.Zero
        hoverPageIndex = -1
        hoverSlotIndex = -1
        hoveringDock = false
        hoverDockSlot = -1
    }
}

@Composable
fun rememberDragState(): DragState {
    return remember { DragState() }
}