package com.example.launcherios.data

/**
 * Représente l'organisation choisie par l'utilisateur.
 */
data class LauncherLayout(
    val pages: List<List<String>>,
    val dock: List<String>,
    val hidden: Set<String> = emptySet()  // 🆕 packages volontairement cachés
) {
    companion object {
        val Empty = LauncherLayout(
            pages = listOf(emptyList()),
            dock = emptyList(),
            hidden = emptySet()
        )

        const val APPS_PER_PAGE = 24
        const val DOCK_MAX_SIZE = 4
    }

    /**
     * Retourne tous les packageNames présents dans le layout (pages + dock + hidden).
     */
    fun allPackages(): Set<String> {
        return pages.flatten().toSet() + dock.toSet() + hidden
    }
}

sealed class LauncherSlot {
    data class Page(val pageIndex: Int, val position: Int) : LauncherSlot()
    data class Dock(val position: Int) : LauncherSlot()
}