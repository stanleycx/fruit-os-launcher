package com.example.launcherios.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * Affiche les petits points en bas qui indiquent la page actuelle, style iOS.
 *
 * @param pageCount Nombre total de pages
 * @param currentPage Index de la page actuellement affichée (0-indexed)
 */
@Composable
fun PageIndicator(
    pageCount: Int,
    currentPage: Int,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(pageCount) { index ->
            // Animation de couleur entre page active et inactive
            val color by animateColorAsState(
                targetValue = if (index == currentPage) {
                    Color.White.copy(alpha = 1f)
                } else {
                    Color.White.copy(alpha = 0.40f)
                },
                label = "page_indicator_color"
            )

            androidx.compose.foundation.layout.Box(
                modifier = Modifier
                    .size(6.dp)  // un peu plus petit, plus discret
                    .clip(CircleShape)
                    .background(color)
            )
        }
    }
}