package com.example.launcherios.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/**
 * S'occupe de récupérer la liste des apps installées sur le téléphone.
 */
class AppRepository(private val context: Context) {

    /**
     * Renvoie toutes les apps "lançables" (celles qui apparaissent dans le tiroir).
     * On exclut notre propre launcher pour éviter de l'afficher dans sa propre liste.
     */
    fun loadInstalledApps(): List<AppInfo> {
        val packageManager = context.packageManager

        // On crée une "requête" Android : "donne-moi toutes les activités qui peuvent
        // être lancées depuis l'écran d'accueil (= apps avec une icône dans le tiroir)"
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        // On exécute la requête
        val resolveInfos = packageManager.queryIntentActivities(intent, 0)

        // On transforme la liste brute en notre modèle AppInfo,
        // en excluant notre propre launcher
        return resolveInfos
            .filter { it.activityInfo.packageName != context.packageName }
            .map { resolveInfo ->
                AppInfo(
                    label = resolveInfo.loadLabel(packageManager).toString(),
                    packageName = resolveInfo.activityInfo.packageName,
                    icon = resolveInfo.loadIcon(packageManager)
                )
            }
            .sortedBy { it.label.lowercase() }  // Tri alphabétique
    }

    /**
     * Lance une app par son packageName.
     */
    fun launchApp(packageName: String) {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            // FLAG_ACTIVITY_NEW_TASK est requis quand on lance depuis un launcher
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        }
    }
}