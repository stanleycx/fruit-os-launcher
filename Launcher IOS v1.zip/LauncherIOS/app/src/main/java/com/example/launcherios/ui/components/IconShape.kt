package com.example.launcherios.ui.components

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Shape

/**
 * La forme iOS d'une icône d'app : un "squircle" (carré aux coins très arrondis).
 *
 * iOS utilise techniquement une superellipse, mais un RoundedCornerShape avec
 * un rayon d'environ 23% de la taille donne un rendu très proche visuellement.
 *
 * @param sizeDp Taille de l'icône en dp (pour calculer le rayon)
 */
fun iosIconShape(sizeDp: Int = 60): Shape {
    // Sur iOS, le coin a un rayon d'environ 22.5% de la taille de l'icône
    val cornerRadius = (sizeDp * 0.32f).toInt()
    return RoundedCornerShape(cornerRadius)
}

/**
 * Forme par défaut pour les icônes de 60dp (la taille standard de nos icônes).
 */
val IosIconShape: Shape = iosIconShape(60)