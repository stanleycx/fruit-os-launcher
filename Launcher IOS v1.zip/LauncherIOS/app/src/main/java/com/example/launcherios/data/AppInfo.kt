package com.example.launcherios.data

import android.graphics.drawable.Drawable

/**
 * Représente une app installée sur le téléphone.
 *
 * @param label Le nom affiché de l'app (ex: "WhatsApp")
 * @param packageName L'identifiant unique de l'app (ex: "com.whatsapp")
 * @param icon L'icône brute de l'app (peut être adaptive ou pas)
 */
data class AppInfo(
    val label: String,
    val packageName: String,
    val icon: Drawable
)