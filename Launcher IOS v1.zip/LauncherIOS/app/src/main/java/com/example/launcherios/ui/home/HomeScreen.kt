package com.example.launcherios.ui.home

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.launcherios.data.AppInfo
import com.example.launcherios.data.AppRepository
import com.example.launcherios.data.LauncherState
import com.example.launcherios.data.LayoutRepository
import com.example.launcherios.data.buildLauncherState
import com.example.launcherios.data.toLayout
import com.example.launcherios.ui.components.PageIndicator
import com.example.launcherios.ui.dock.Dock
import kotlinx.coroutines.launch
import dev.chrisbanes.haze.hazeSource
import androidx.compose.foundation.background
import com.example.launcherios.ui.components.WallpaperBackground

@Composable
fun HomeScreen() {
    val context = LocalContext.current
    val appRepository = remember { AppRepository(context) }
    val layoutRepository = remember { LayoutRepository(context) }
    val scope = rememberCoroutineScope()

    var state by remember { mutableStateOf<LauncherState?>(null) }

    LaunchedEffect(Unit) {
        val installedApps = appRepository.loadInstalledApps()
        val layout = layoutRepository.load()
        state = buildLauncherState(installedApps, layout)
    }

    val updateState: (LauncherState) -> Unit = { newState ->
        state = newState
        scope.launch {
            layoutRepository.save(newState.toLayout())
        }
    }

    val currentState = state ?: return

    val pagerState = rememberPagerState(
        pageCount = { currentState.pages.size.coerceAtLeast(1) }
    )

    val editMode = rememberEditModeState()
    val dragState = rememberDragState()  // 🆕 état du drag
    val hazeState = remember { dev.chrisbanes.haze.HazeState() }

    // Factorisation de la logique de drop, utilisée par la grille ET le dock
    val handleDragEnd: () -> Unit = {
        val dragged = dragState.draggedApp

        if (dragged != null) {
            val isDockTarget = dragState.isOverDock()

            if (isDockTarget) {
                val dockSlot = dragState.computeDockSlot()
                updateState(moveAppToDock(currentState, dragged, dockSlot))
                // 🆕 Haptic confirmation : drop réussi sur le dock
                com.example.launcherios.ui.components.Haptics.light(context)
            } else if (dragState.hoverPageIndex >= 0 && dragState.hoverSlotIndex >= 0) {
                updateState(
                    moveAppToSlot(
                        state = currentState,
                        app = dragged,
                        targetPage = dragState.hoverPageIndex,
                        targetSlot = dragState.hoverSlotIndex
                    )
                )
                // 🆕 Haptic confirmation : drop réussi sur la grille
                com.example.launcherios.ui.components.Haptics.light(context)
            }
        }

        dragState.end()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(editMode.isEditing) {
                if (editMode.isEditing) {
                    detectTapGestures(onTap = { editMode.exit() })
                }
            }
    ) {
        // COUCHE 1 : tout ce qui peut être blurré (source du flou)
        Box(modifier = Modifier.fillMaxSize().hazeSource(state = hazeState)) {
            WallpaperBackground()

            // Pages d'apps
            Column(modifier = Modifier.fillMaxSize()) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.weight(1f),
                    userScrollEnabled = !dragState.isDragging
                ) { pageIndex ->
                    val pageApps = currentState.pages.getOrNull(pageIndex) ?: emptyList()
                    HomePage(
                        apps = pageApps,
                        appRepository = appRepository,
                        editMode = editMode,
                        dragState = dragState,
                        pageIndex = pageIndex,
                        onLongPress = { editMode.enter() },
                        onRemoveApp = { app ->
                            val newPages = currentState.pages.map { page ->
                                page.filter { it.packageName != app.packageName }
                            }
                            val newDock = currentState.dock.filter {
                                it.packageName != app.packageName
                            }
                            val newHidden = currentState.hidden + app.packageName
                            updateState(
                                LauncherState(
                                    pages = newPages,
                                    dock = newDock,
                                    hidden = newHidden
                                )
                            )
                        },
                        onDragStart = { app, position -> dragState.start(app, position) },
                        onDragDelta = { delta -> dragState.update(dragState.position + delta) },
                        onDragEnd = handleDragEnd
                    )
                }
                Spacer(modifier = Modifier.height(140.dp))
            }
        }

// COUCHE 2 : dock + indicateur, EN DEHORS du hazeSource → peut avoir hazeEffect
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (currentState.pages.size > 1) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    PageIndicator(
                        pageCount = currentState.pages.size,
                        currentPage = pagerState.currentPage
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Dock(
                apps = currentState.dock,
                appRepository = appRepository,
                editMode = editMode,
                dragState = dragState,
                hazeState = hazeState,
                onLongPress = { editMode.enter() },
                onRemoveApp = { app ->
                    val newPages = currentState.pages.map { page ->
                        page.filter { it.packageName != app.packageName }
                    }
                    val newDock = currentState.dock.filter {
                        it.packageName != app.packageName
                    }
                    val newHidden = currentState.hidden + app.packageName
                    updateState(
                        LauncherState(
                            pages = newPages,
                            dock = newDock,
                            hidden = newHidden
                        )
                    )
                },
                onDragStart = { app, position -> dragState.start(app, position) },
                onDragDelta = { delta -> dragState.update(dragState.position + delta) },
                onDragEnd = handleDragEnd
            )
            Spacer(modifier = Modifier.height(20.dp))
        }

        // 🆕 Le fantôme de drag par-dessus tout le reste
        DragGhost(dragState = dragState)
    }
    /**
     * Déplace une app vers une nouvelle position dans le LauncherState.
     *
     * Retire l'app de sa position actuelle (page ou dock), puis l'insère
     * dans la page cible à la position cible.
     */

}

private fun moveAppToSlot(
    state: LauncherState,
    app: AppInfo,
    targetPage: Int,
    targetSlot: Int
): LauncherState {
    // 1. Retire l'app de toutes les pages et du dock
    val pagesWithoutApp = state.pages.map { page ->
        page.filter { it.packageName != app.packageName }
    }.toMutableList()

    val dockWithoutApp = state.dock.filter { it.packageName != app.packageName }

    // 2. S'assurer que la page cible existe (au cas où on aurait des pages vides)
    while (pagesWithoutApp.size <= targetPage) {
        pagesWithoutApp.add(emptyList())
    }

    // 3. Insère l'app à la position cible dans la page cible
    val targetPageApps = pagesWithoutApp[targetPage].toMutableList()
    val safeSlot = targetSlot.coerceIn(0, targetPageApps.size)
    targetPageApps.add(safeSlot, app)
    pagesWithoutApp[targetPage] = targetPageApps

    return LauncherState(
        pages = pagesWithoutApp,
        dock = dockWithoutApp,
        hidden = state.hidden
    )
}

/**
 * Déplace une app vers le dock à la position donnée.
 * Si le dock est plein (4 apps), l'opération est refusée et l'état d'origine est retourné.
 */
private fun moveAppToDock(
    state: LauncherState,
    app: AppInfo,
    targetSlot: Int
): LauncherState {
    val pagesWithoutApp = state.pages.map { page ->
        page.filter { it.packageName != app.packageName }
    }
    val dockWithoutApp = state.dock.filter { it.packageName != app.packageName }

    // Refus si le dock est plein (sauf si l'app était déjà dedans : on autorise le repositionnement)
    val wasInDock = state.dock.any { it.packageName == app.packageName }
    if (!wasInDock && dockWithoutApp.size >= 4) {
        return state  // Pas de changement : l'app revient à sa place d'origine
    }

    val newDock = dockWithoutApp.toMutableList()
    val safeSlot = targetSlot.coerceIn(0, newDock.size)
    newDock.add(safeSlot, app)

    return LauncherState(
        pages = pagesWithoutApp,
        dock = newDock,
        hidden = state.hidden
    )
}