package com.example.launcherios.data

/**
 * Représente l'état complet du launcher prêt à être affiché.
 *
 * On garde aussi la liste de hidden pour pouvoir la repropager lors des sauvegardes.
 */
data class LauncherState(
    val pages: List<List<AppInfo>>,
    val dock: List<AppInfo>,
    val hidden: Set<String> = emptySet()
)

/**
 * Fusionne les apps installées avec le layout sauvegardé.
 *
 * Règles :
 * - Apps cachées (hidden) → ne sont pas affichées
 * - Apps du layout pas installées → retirées
 * - Apps installées pas dans le layout et pas cachées → ajoutées à la fin
 */
fun buildLauncherState(
    installedApps: List<AppInfo>,
    layout: LauncherLayout
): LauncherState {
    val appsByPackage = installedApps.associateBy { it.packageName }

    val dock = layout.dock.mapNotNull { appsByPackage[it] }

    val laidOutPages = layout.pages.map { page ->
        page.mapNotNull { appsByPackage[it] }
    }

    // Apps fraîchement installées : pas encore placées ET pas cachées
    val placedPackages = layout.allPackages()  // inclut maintenant les hidden
    val newApps = installedApps.filter { it.packageName !in placedPackages }

    val finalPages = distributeNewApps(laidOutPages, newApps)

    return LauncherState(
        pages = finalPages,
        dock = dock,
        hidden = layout.hidden  // on conserve la liste cachée
    )
}

private fun distributeNewApps(
    existingPages: List<List<AppInfo>>,
    newApps: List<AppInfo>
): List<List<AppInfo>> {
    if (newApps.isEmpty()) {
        return existingPages.ifEmpty { listOf(emptyList()) }
    }

    val result = existingPages.map { it.toMutableList() }.toMutableList()
    if (result.isEmpty()) result.add(mutableListOf())

    val maxPerPage = LauncherLayout.APPS_PER_PAGE
    val queue = newApps.toMutableList()

    for (page in result) {
        while (page.size < maxPerPage && queue.isNotEmpty()) {
            page.add(queue.removeAt(0))
        }
    }

    while (queue.isNotEmpty()) {
        val newPage = mutableListOf<AppInfo>()
        while (newPage.size < maxPerPage && queue.isNotEmpty()) {
            newPage.add(queue.removeAt(0))
        }
        result.add(newPage)
    }

    return result
}

/**
 * Convertit un LauncherState en LauncherLayout pour la sauvegarde.
 */
fun LauncherState.toLayout(): LauncherLayout {
    return LauncherLayout(
        pages = pages.map { page -> page.map { it.packageName } },
        dock = dock.map { it.packageName },
        hidden = hidden
    )
}