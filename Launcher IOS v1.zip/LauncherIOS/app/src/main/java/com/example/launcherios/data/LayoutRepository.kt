package com.example.launcherios.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.layoutDataStore by preferencesDataStore(name = "launcher_layout")
private val LAYOUT_KEY = stringPreferencesKey("layout_data")

/**
 * Gère la sauvegarde et le chargement du LauncherLayout sur disque (DataStore).
 *
 * Format texte :
 *   DOCK
 *   com.app1
 *   PAGE
 *   com.app2
 *   PAGE
 *   com.app3
 *   HIDDEN
 *   com.app4
 */
class LayoutRepository(private val context: Context) {

    suspend fun load(): LauncherLayout {
        val raw = context.layoutDataStore.data
            .map { prefs: Preferences -> prefs[LAYOUT_KEY] ?: "" }
            .first()

        return if (raw.isBlank()) LauncherLayout.Empty else deserialize(raw)
    }

    suspend fun save(layout: LauncherLayout) {
        val serialized = serialize(layout)
        context.layoutDataStore.edit { prefs ->
            prefs[LAYOUT_KEY] = serialized
        }
    }

    private fun serialize(layout: LauncherLayout): String {
        val lines = mutableListOf<String>()

        lines.add("DOCK")
        lines.addAll(layout.dock)

        layout.pages.forEach { page ->
            lines.add("PAGE")
            lines.addAll(page)
        }

        if (layout.hidden.isNotEmpty()) {
            lines.add("HIDDEN")
            lines.addAll(layout.hidden)
        }

        return lines.joinToString("\n")
    }

    private fun deserialize(raw: String): LauncherLayout {
        val dock = mutableListOf<String>()
        val pages = mutableListOf<MutableList<String>>()
        val hidden = mutableSetOf<String>()

        var currentSection: String? = null

        for (line in raw.lines()) {
            when (line) {
                "DOCK" -> currentSection = "DOCK"
                "PAGE" -> {
                    currentSection = "PAGE"
                    pages.add(mutableListOf())
                }
                "HIDDEN" -> currentSection = "HIDDEN"
                else -> {
                    if (line.isBlank()) continue
                    when (currentSection) {
                        "DOCK" -> dock.add(line)
                        "PAGE" -> pages.lastOrNull()?.add(line)
                        "HIDDEN" -> hidden.add(line)
                    }
                }
            }
        }

        return LauncherLayout(
            pages = if (pages.isEmpty()) listOf(emptyList()) else pages,
            dock = dock,
            hidden = hidden
        )
    }
}